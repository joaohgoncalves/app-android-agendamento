package br.com.beautystyle.ui.activity;

public interface ContantsActivity {

    int REQUEST_CODE_INSERT_EVENT = 1;
    int REQUEST_CODE_UPDATE_EVENT = 2;
    int REQUEST_CODE_UPDATE_EXPENSE = 3;
    int REQUEST_CODE_INSERT_EXPENSE = 4;
    int INVALID_POSITION = -1;
    String KEY_CLICK_FAB_NAVIGATION = "fabNavigation";
    String TAG_EVENT_DURATION = "eventDuration";

}
