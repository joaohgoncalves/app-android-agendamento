package br.com.beautystyle.ui.adapter;

public interface ConstantsAdapter {
    String ITEM_MENU_REMOVE = "Excluir";
    String ITEM_MENU_UPDATE = "Editar";
    String BLOCK_TIME = "HORÁRIO BLOQUEADO";
}
