package br.com.beautystyle.util;

public interface ConstantsUtil {
    String DD_MM_YYYY = "dd/MM/yyyy";
    String MMMM = "MMMM";
    String MMMM_YYYY = "MMMM / yyyy";
    String YYYY = "yyyy";
    String DD = "dd";
    String E = "E";
    String DESIRED_FORMAT = "R$ ";
    String REMOVE_SYMBOL = "";
}
